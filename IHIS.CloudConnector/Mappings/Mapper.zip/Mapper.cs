﻿using System.Collections.Generic;
using System.Reflection;
using Otis;

namespace IHIS.CloudConnector.Mappings
{
    using System;
    using System.IO;
    using System.Windows.Forms;

    public class Mapper : MarshalByRefObject
    {
        // ReSharper disable once InconsistentNaming
        private static Mapper instance = new Mapper();

        public static DateTime start = DateTime.Now;
            
        //private Configuration _cfg = new Configuration();
        private object assembler = new Assembler();

        private Mapper()
        {           
            //_cfg.GenerationOptions.Namespace = "Otis.IHIS.Cloud";
            //if (!File.Exists(Application.StartupPath + "\\otis.cloud.dll"))
            //{
            //    _cfg.GenerationOptions.OutputFile = Application.StartupPath + "\\otis.cloud.dll";
            //    _cfg.GenerationOptions.OutputType = OutputType.Assembly;        
            //    _cfg.AddAssemblyResources(Assembly.GetExecutingAssembly(), "otis.xml");  
            //}
            //else
            //{
            //    Assembly assembly = AppDomain.CurrentDomain.Load("otis.cloud, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null", AppDomain.CurrentDomain.Evidence);
            //    assembler = assembly.CreateInstance("otis.cloud.Assembler");
            //}    
            //try
            //{
            //    //Assembly ab = AppDomain.CurrentDomain.Load(typeof(Assembler).Assembly.FullName, AppDomain.CurrentDomain.Evidence);
            //    assembler = AppDomain.CurrentDomain.CreateInstanceFromAndUnwrap(typeof(Assembler).Assembly.FullName, "IHIS.CloudConnector.Assembler") as Assembler;
            //}
            //catch (Exception e)
            //{
            //    MessageBox.Show(e.Message);
            //}
            //if (assembler == null)
            //{
            //    assembler = GetType().Assembly.CreateInstance("IHIS.CloudConnector.Assembler");
            //}
            
        }

        public static void Initialize(object assembler)
        {
            instance.assembler = assembler;
        }

        public static Mapper Instance {
            get {
                //if (instance.assembler == null)
                //{
                //    instance.assembler = instance.GetType().Assembly.CreateInstance("IHIS.CloudConnector.Assembler");
                //}
                return instance;
            }
        }

        public TD Map<TD, TS>(TS source)
        {
            IAssembler<TD, TS> asm = assembler as IAssembler<TD, TS>;
            return asm.AssembleFrom(source);
        }

        public void Map<TD, TS>(TD target, TS source)
        {
            IAssembler<TD, TS> asm = assembler as IAssembler<TD, TS>;
            asm.Assemble(target, source);
        }

        public TD[] MapToArray<TD, TS>(IEnumerable<TS> source)
        {
            IAssembler<TD, TS> asm = assembler as IAssembler<TD, TS>;
            return asm.ToArray(source);
        }

        public List<TD> MapToList<TD, TS>(IEnumerable<TS> source)
        {
            IAssembler<TD, TS> asm = assembler as IAssembler<TD, TS>;
            return asm.ToList(source);
        }
    }
}